from os import system

system("cls")

print("2.feladat: Szökőév listázó")

ev1 = int(input("Adj meg egy évet: "))
ev2 = int(input("Adj meg egy másik évet: "))
szokoev=[]

for i in range:
    if szam1 % 400 == 0 and szam2 % 400==0 or szam1 % 4 == 0  and szam2 % 4 == 0:
        szokoev.append()
        print()
    else:
        print("Nincs szökőév a megadott tartományban")

